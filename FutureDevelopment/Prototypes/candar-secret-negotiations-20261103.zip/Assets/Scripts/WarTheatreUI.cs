using System.Linq;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class WarTheatreUI : MonoBehaviour
{
    static GameObject root; RectTransform map; Transform overlays,detail; TMP_Text hover;
    readonly Dictionary<string,List<TerritoryGraphic>> powerShapes=new Dictionary<string,List<TerritoryGraphic>>();
    TerritoryGraphic hoveredShape;
    void Register(TerritoryGraphic shape,WarTheatre.Region region) {
        string key=WarTheatre.HighlightKey(region);
        if(!powerShapes.TryGetValue(key,out var shapes)){shapes=new List<TerritoryGraphic>();powerShapes.Add(key,shapes);}
        shapes.Add(shape);shape.Click=()=>Select(region);shape.Hover=on=>HoverPower(region,shape,on);
    }
    void ClearHover() {
        foreach(var shapes in powerShapes.Values)foreach(var shape in shapes)if(shape!=null)shape.SetHighlighted(false);
        hoveredShape=null;if(hover!=null)hover.text=HoverHint;
    }
    void HoverPower(WarTheatre.Region region,TerritoryGraphic source,bool on) {
        string key=WarTheatre.HighlightKey(region);
        if(!on){if(hoveredShape==source)ClearHover();return;}
        ClearHover();hoveredShape=source;
        if(powerShapes.TryGetValue(key,out var shapes))foreach(var shape in shapes)shape.SetHighlighted(true);
        var power=WarTheatre.DiplomaticPower(region);
        string title=power.name+(power.id==region.id?"":" · "+region.name);
        bool hasCourt=CountryDiplomacy.Index(string.IsNullOrEmpty(power.group)?power.id:power.group)>=0;
        hover.text=title+" · "+(region.kind=="province"?WarTheatre.Status(region):region.kind=="capital"?"Enter the Palace":hasCourt?"All possessions highlighted · Select for diplomacy":"Independent territory");
    }
    void OnDisable(){ClearHover();}
    bool provinces=true,allies=true; float zoom=1; Vector2 fit;
    const string HoverHint="Hover for gold outline · Click a territory · Scroll to zoom · Drag to explore";
    public static bool Close(){if(root==null)return false;root.SetActive(false);Destroy(root);root=null;return true;}
    public static void Show(){
        Close();root=new GameObject("War Beyond the Walls map",typeof(RectTransform),typeof(Canvas),typeof(CanvasScaler),typeof(GraphicRaycaster),typeof(Image),typeof(WarTheatreUI));
        var canvas=root.GetComponent<Canvas>();canvas.renderMode=RenderMode.ScreenSpaceOverlay;canvas.sortingOrder=220;
        var scaler=root.GetComponent<CanvasScaler>();scaler.uiScaleMode=CanvasScaler.ScaleMode.ScaleWithScreenSize;scaler.referenceResolution=new Vector2(1600,900);scaler.matchWidthOrHeight=.5f;
        root.GetComponent<Image>().color=new Color(.018f,.035f,.049f,1);var ui=root.GetComponent<WarTheatreUI>();
        CampaignHUD.Label(root.transform,"WAR BEYOND THE WALLS",new Vector2(.025f,.935f),new Vector2(.56f,.995f),30);
        CampaignHUD.MakeButton(root.transform,"Historical atlas",new Vector2(.66f,.94f),new Vector2(.81f,.99f),WorldMapUI.Show);
        CampaignHUD.MakeButton(root.transform,"Return",new Vector2(.83f,.94f),new Vector2(.975f,.99f),()=>Close());
        CampaignHUD.MakeButton(root.transform,"Ottoman provinces",new Vector2(.025f,.875f),new Vector2(.20f,.925f),()=>{ui.provinces=!ui.provinces;ui.Draw();});
        CampaignHUD.MakeButton(root.transform,"Foreign powers",new Vector2(.21f,.875f),new Vector2(.37f,.925f),()=>{ui.allies=!ui.allies;ui.Draw();});
        CampaignHUD.MakeButton(root.transform,"Symbols",new Vector2(.38f,.875f),new Vector2(.49f,.925f),ui.Legend);
        CampaignHUD.MakeButton(root.transform,"−",new Vector2(.79f,.875f),new Vector2(.84f,.925f),()=>ui.Resize(ui.zoom/1.35f));
        CampaignHUD.MakeButton(root.transform,"+",new Vector2(.85f,.875f),new Vector2(.90f,.925f),()=>ui.Resize(ui.zoom*1.35f));
        CampaignHUD.MakeButton(root.transform,"Fit",new Vector2(.91f,.875f),new Vector2(.975f,.925f),()=>{ui.Resize(1);ui.map.anchoredPosition=Vector2.zero;});
        var area=CampaignHUD.Panel(root.transform,"Theatre viewport",new Vector2(.025f,.285f),new Vector2(.975f,.86f));area.AddComponent<RectMask2D>();
        var picture=new GameObject("Geographic base",typeof(RectTransform),typeof(RawImage));picture.transform.SetParent(area.transform,false);ui.map=picture.GetComponent<RectTransform>();ui.map.anchorMin=ui.map.anchorMax=new Vector2(.5f,.5f);
        var tex=Resources.Load<Texture2D>("UI/Maps/WarTheatreGeography");picture.GetComponent<RawImage>().texture=tex;
        var scroll=area.AddComponent<ScrollRect>();scroll.viewport=area.GetComponent<RectTransform>();scroll.content=ui.map;scroll.movementType=ScrollRect.MovementType.Clamped;scroll.inertia=false;scroll.scrollSensitivity=0;
        Canvas.ForceUpdateCanvases();var bounds=scroll.viewport.rect;float aspect=tex==null?3:(float)tex.width/tex.height;float width=Mathf.Min(bounds.width,bounds.height*aspect);ui.fit=new Vector2(width,width/aspect);ui.Resize(1);
        ui.detail=CampaignHUD.Panel(root.transform,"Province information",new Vector2(.025f,.045f),new Vector2(.975f,.245f)).transform;
        ui.hover=CampaignHUD.Label(root.transform,HoverHint,new Vector2(.025f,.248f),new Vector2(.975f,.283f),19);
        CampaignHUD.Label(root.transform,"Frontiers circa 1452 · Schematic borders and contested marches · Select a coast or realm to reach its diplomatic court.",new Vector2(.025f,.002f),new Vector2(.975f,.04f),16);
        ui.Draw();
        CampaignHUD.Label(ui.detail,"Choose a territory",new Vector2(.02f,.72f),new Vector2(.98f,.97f),28);
        CampaignHUD.Explanation(ui.detail,"Select a province or realm to view its information.",new Vector2(.02f,.12f),new Vector2(.98f,.66f),22);
    }
    void Resize(float value){zoom=Mathf.Clamp(value,1,3);map.sizeDelta=fit*zoom;}
    void Update(){if(WorldMapUIOpen())return;float delta=Input.mouseScrollDelta.y;if(delta!=0&&RectTransformUtility.RectangleContainsScreenPoint(map.parent as RectTransform,Input.mousePosition))Resize(zoom*Mathf.Pow(1.12f,delta));}
    bool WorldMapUIOpen()=>GameObject.Find("World map viewer")!=null;
    void Clear(Transform t){foreach(Transform child in t){child.gameObject.SetActive(false);Destroy(child.gameObject);}}
    void Draw(){
        ClearHover();powerShapes.Clear();
        if(overlays!=null){overlays.gameObject.SetActive(false);Destroy(overlays.gameObject);}overlays=CampaignHUD.Panel(map,"Political overlays",Vector2.zero,Vector2.one).transform;overlays.GetComponent<Image>().color=Color.clear;overlays.GetComponent<Image>().raycastTarget=false;
        foreach(var r in WarTheatre.Data.regions){if(r.kind=="province"?!provinces:!allies&&r.kind!="capital")continue;
            if(r.points.Length>=3){var go=new GameObject(r.id,typeof(RectTransform),typeof(TerritoryGraphic));go.transform.SetParent(overlays,false);var rt=go.GetComponent<RectTransform>();rt.anchorMin=Vector2.zero;rt.anchorMax=Vector2.one;rt.offsetMin=rt.offsetMax=Vector2.zero;var shape=go.GetComponent<TerritoryGraphic>();shape.Points=r.points;shape.color=WarTheatre.Tint(r);Register(shape,r);}
        }
        foreach(var r in WarTheatre.Data.regions){if(r.kind=="province"?!provinces:!allies&&r.kind!="capital")continue;
            if(r.kind=="colony"||r.kind=="capital"){
                // Separate the Galata port marker from the Palace hotspot without moving its geographic anchor.
                Vector2 markerOffset=r.id=="galata"?new Vector2(-16,14):Vector2.zero;
                if(markerOffset!=Vector2.zero){
                    var leader=new GameObject("Galata leader",typeof(RectTransform),typeof(Image));leader.transform.SetParent(overlays,false);
                    var lr=leader.GetComponent<RectTransform>();lr.anchorMin=lr.anchorMax=r.label;lr.anchoredPosition=markerOffset*.5f;
                    lr.sizeDelta=new Vector2(markerOffset.magnitude,1);lr.localEulerAngles=new Vector3(0,0,Mathf.Atan2(markerOffset.y,markerOffset.x)*Mathf.Rad2Deg);
                    var ink=leader.GetComponent<Image>();ink.color=new Color(.87f,.78f,.48f,.8f);ink.raycastTarget=false;
                }
                var go=new GameObject(r.name,typeof(RectTransform),typeof(TerritoryGraphic));go.transform.SetParent(overlays,false);var rt=go.GetComponent<RectTransform>();rt.anchorMin=rt.anchorMax=r.label;rt.anchoredPosition=markerOffset;rt.sizeDelta=Vector2.one*(r.kind=="capital"?20:12);var shape=go.GetComponent<TerritoryGraphic>();shape.Points=new[]{new Vector2(.5f,0),new Vector2(1,.5f),new Vector2(.5f,1),new Vector2(0,.5f)};shape.color=r.kind=="capital"?new Color(.75f,.25f,.9f):WarTheatre.Tint(r);Register(shape,r);}
            if(r.kind!="colony"&&r.kind!="island"){
                bool eastern=r.id=="aq_qoyunlu";
                bool compact=new[]{"savoy","milan","po_lordships","florence","siena","papacy","genoa","theodoro","sardinia","corsica","athens","ionian_tocco"}.Contains(r.id);
                string caption=eastern?"Turkmen\nConfederations":r.id=="milan"?"Milan":r.id=="athens"?"Athens":r.id=="ionian_tocco"?"Ionian\nlordships":r.id=="po_lordships"?"Po lords":r.id=="papacy"?"Papal\nStates":r.name;
                Vector2 half=eastern?new Vector2(.065f,.032f):compact?new Vector2(.027f,(r.id=="papacy"||r.id=="ionian_tocco")?.03f:.018f):new Vector2(.047f,.016f);
                // Edge possessions remain readable even when their territory continues beyond the atlas.
                Vector2 centre=new Vector2(Mathf.Clamp(r.label.x,half.x,1-half.x),Mathf.Clamp(r.label.y,half.y,1-half.y));
                if(r.id=="savoy")centre.y-=.028f;
                var text=CampaignHUD.Label(overlays,caption,centre-half,centre+half,r.kind=="capital"?14:compact?13:16);text.alignment=TextAlignmentOptions.Center;text.raycastTarget=false;text.fontStyle=FontStyles.Bold;text.enableAutoSizing=true;text.fontSizeMin=10;text.fontSizeMax=compact?13:16;text.color=new Color(1,.95f,.78f);text.gameObject.AddComponent<Shadow>().effectDistance=new Vector2(1,-1);if(r.kind=="capital")text.rectTransform.anchoredPosition+=new Vector2(0,-19);}
            if(r.kind=="province")ProvincialMapMarkers.Add(overlays,r);
        }
        foreach(var r in WarTheatre.Data.regions.Where(r=>r.id==r.group&&CountryDiplomacy.Index(r.group)>=0&&WarTheatre.AtWar(r)))Icon(overlays,new[]{"venice","genoa","naples","cyprus"}.Contains(r.group)?5:4,r.front,38,()=>WarReport(r));
        MaritimeMapMedallions.Add(overlays,detail,hover,ClearHover);
    }
    static void Icon(Transform parent,int index,Vector2 point,float size,UnityEngine.Events.UnityAction action=null){
        var go=new GameObject("Theatre marker "+index,typeof(RectTransform),typeof(RawImage));go.transform.SetParent(parent,false);var rt=go.GetComponent<RectTransform>();rt.anchorMin=rt.anchorMax=point;rt.sizeDelta=Vector2.one*size;var image=go.GetComponent<RawImage>();image.texture=Resources.Load<Texture2D>("UI/Maps/WarTheatreSymbols");image.uvRect=new Rect(index%4*.25f,(3-index/4)*.25f,.25f,.25f);image.raycastTarget=action!=null;if(action!=null)go.AddComponent<Button>().onClick.AddListener(action);
    }
    void Select(WarTheatre.Region r){
        if(r.id=="candar"){Close();FindObjectOfType<CouncilUI>(true).CandarCourt();return;}
        if(r.kind=="capital"){Close();FindObjectOfType<CouncilUI>(true).Palace();return;}if(r.kind=="province"){ProvincialConflictUI.Show(r.id);return;}Clear(detail);
        var power=WarTheatre.DiplomaticPower(r);
        int country=CountryDiplomacy.Index(string.IsNullOrEmpty(power.group)?power.id:power.group);
        CampaignHUD.Label(detail,power.name,new Vector2(.02f,.72f),new Vector2(.73f,.97f),28);
        string text;
        if(r.kind=="province")text=WarTheatre.Status(r)+" · Authority "+WarTheatre.Control(r)+"% · Resistance "+ProvinceCampaign.Resistance(r.id)+"%\n"+r.referenceName+" · "+r.role+"\n"+(ProvinceCampaign.Agent(r.id)>0?ProvinceCampaign.Status(r.id):"No imperial agent assigned here.");
        else if(country>=0)text=CountryDiplomacy.Attitude(country)+" · "+CountryDiplomacy.FinalChance(country).ToString("0.##")+"% acceptance · "+CountryDiplomacy.WarStatus(country)+"\n"+CountryDiplomacy.EnvoyStatus(country)+"\n"+r.note;
        else if(r.kind=="neutral")text=r.referenceName+"\n"+r.note;
        else text=(power.id==r.id?"Realm and dependencies":r.name+" · "+power.name+" connection")+" · "+(WarTheatre.AtWar(power)?"War reported":"No regional war reported")+"\n"+r.note;
        var body=CampaignHUD.Explanation(detail,text,new Vector2(.02f,.06f),new Vector2(.73f,.71f),20);body.enableAutoSizing=true;body.fontSizeMin=17;body.fontSizeMax=20;
        if(r.kind=="province")CampaignHUD.MakeButton(detail,"Provincial operations",new Vector2(.76f,.45f),new Vector2(.98f,.83f),()=>{Close();FindObjectOfType<CouncilUI>(true).ProvincialOperationsFor(r.id);});
        else if(country>=0)CampaignHUD.MakeButton(detail,"Diplomatic relations",new Vector2(.76f,.45f),new Vector2(.98f,.83f),()=>{Close();FindObjectOfType<CouncilUI>(true).DiplomaticPower(country);});
        CampaignHUD.Label(detail,r.kind=="province"?"Output follows Wealth; chaos halts exports.\nImperial provinces send tribute.":"An aid expedition does not\nautomatically mean a foreign war.",new Vector2(.76f,.06f),new Vector2(.98f,.4f),17);
    }
    void WarReport(WarTheatre.Region r){var power=WarTheatre.DiplomaticPower(r);Close();FindObjectOfType<CouncilUI>(true).DiplomaticRelationsFor(power.group);}
    void Legend(){Clear(detail);string[] names={"Agent","Network","Insurrection","Imperial control","Land battle","Naval battle","Army","Fleet","Provisions","Artillery","Garrison","Revenue","Sabotage","Envoy","Liberation","Order"};for(int i=0;i<16;i++){float x=.06f+(i%8)*.126f,y=i<8?.73f:.26f;Icon(detail,i,new Vector2(x,y),43);var label=CampaignHUD.Label(detail,names[i],new Vector2(x-.06f,y-.24f),new Vector2(x+.06f,y-.12f),14);label.alignment=TextAlignmentOptions.Center;label.raycastTarget=false;}}
}
